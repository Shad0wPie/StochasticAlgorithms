function y = BestFitFunction(x)

    y = (x.^3 - x.^2 + 1)./(x.^4 - x.^2 + 1);

end

